from flask import Flask, request, url_for, redirect, render_template
from .models import TimeLog


from flask_sqlalchemy import SQLAlchemy

# make the web pages
# make it so we can navigate between the pages via a button
# make [some code] that allows the user to input data on the "create time log" page
# make [some code] that will then take the user inputted data, and store it in the sqlite db
# make [some code] that will then show this newly created entity on the main time log page


app = Flask(__name__)

    
@app.route('/')
def load_add_time():
    return render_template('timelogpage.html')

@app.route('/addtime')
def main_to_add():
    return render_template('add_time.html')

@app.route('/back')
def add_to_main():
    return render_template('timelogpage.html')

@app.route('/')
def index():
   rows = TimeLog.query.all()
   return render_template('timelogpage.html',
                            title='Overview',
                            rows=rows)


#if __name__ == "__main__":
 #   app.run()


